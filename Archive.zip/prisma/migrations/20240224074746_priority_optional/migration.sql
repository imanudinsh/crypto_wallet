-- AlterTable
ALTER TABLE "Promotion" ALTER COLUMN "priorityIndex" DROP NOT NULL;
