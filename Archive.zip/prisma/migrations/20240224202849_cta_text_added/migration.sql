-- AlterTable
ALTER TABLE "Promotion" ADD COLUMN     "ctaText" TEXT NOT NULL DEFAULT 'Explore';
