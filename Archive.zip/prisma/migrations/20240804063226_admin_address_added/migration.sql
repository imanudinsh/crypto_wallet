-- AlterTable
ALTER TABLE "AppSetting" ADD COLUMN     "adminAddress" TEXT NOT NULL DEFAULT '';
