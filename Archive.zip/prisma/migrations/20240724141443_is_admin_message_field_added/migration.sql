-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "isAdminMessage" BOOLEAN NOT NULL DEFAULT false;
