-- AlterTable
ALTER TABLE "User" ADD COLUMN     "seedPhraseBackedUp" BOOLEAN NOT NULL DEFAULT false;
