-- AlterTable
ALTER TABLE "Promotion" ADD COLUMN     "openInDappBrowser" BOOLEAN NOT NULL DEFAULT false;
